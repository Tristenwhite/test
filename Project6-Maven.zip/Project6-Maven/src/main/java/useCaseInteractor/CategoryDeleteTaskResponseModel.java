package useCaseInteractor;

public class CategoryDeleteTaskResponseModel {
}
