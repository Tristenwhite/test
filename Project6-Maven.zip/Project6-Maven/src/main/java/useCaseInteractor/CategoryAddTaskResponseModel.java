package useCaseInteractor;

public class CategoryAddTaskResponseModel {
}
