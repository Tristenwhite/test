package useCaseInteractor;

public class ScheduleItemResponseModel {
}
