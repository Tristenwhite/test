package useCaseInteractor;

public class DeleteScheduleItem {


}
