package useCaseInteractor;

public class EditScheduleItem {
}
