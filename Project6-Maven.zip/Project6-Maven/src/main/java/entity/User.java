package entity;

public class User {
    /* User class */
    public String firstname;
    public String lastname;
    public String username;
    public String password;

    }

