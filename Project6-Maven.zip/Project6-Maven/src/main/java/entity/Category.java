package entity;

public interface Category {
    String getName();

    String getHex();

    boolean isStatus();
}
