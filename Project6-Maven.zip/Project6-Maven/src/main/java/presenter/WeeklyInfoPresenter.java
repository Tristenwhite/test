package presenter;

public class WeeklyInfoPresenter {
}
