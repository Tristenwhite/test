package repo;

public class CategoryRepository {
}
