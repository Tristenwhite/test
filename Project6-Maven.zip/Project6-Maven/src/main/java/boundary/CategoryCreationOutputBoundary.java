package boundary;

public class CategoryCreationOutputBoundary {
}
